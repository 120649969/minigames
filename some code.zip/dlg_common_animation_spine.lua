--[[
通用打牌动画播放界面
]]
local play_card_utils = import('logic_net.play_card_utils')
local panel_name = play_card_utils.GetCurrentCommonAnimationTemplateName()
Panel = g_panel_mgr.new_panel_class(panel_name)

-- overwrite
function Panel:init_panel(aniName, func)
 	local has_close = false
 	local max_animation_count = 5
 	local has_register = false
 	for index = 1, max_animation_count do
 		local animation_name = string.format("animation%s", index)
 		if not self[animation_name] then
 			break
 		end
 		if not has_register then
	 		local spine_animation = self[animation_name]
	 		spine_animation:registerSpineEventHandler(function (event)
	 			if has_close then
	 				return
	 			end
	 			has_close = true
	 			if func then func() end
	 			self:get_layer():DelayCall(0, function()
	 				self:close_panel()
	 			end)
			end, sp.EventType.ANIMATION_COMPLETE)
			has_register = true
 		end
 	end
end