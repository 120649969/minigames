-- 打牌的一些通用逻辑
local constant = g_conf_mgr.get_constant('constant')
local _width_card = 62.98

-- common
function GetCardPath(card)
	if card == 0 then
		return constant.DEFAULT_POKER_BG
	end

	local num, tp = GetCardType(card)
	return string.format('gui/badam_ui/poker/%d_%02d.png', tp, num)
end

-- 获取牌的牌的大小和 牌的花色
function GetCardType(card)
	local tp
	local num
	if bit.band(card, 0x0F) == 14 then
		-- 小王
		tp = 0
		num = 14
	elseif bit.band(card, 0x0F) == 15 then
		-- 大王
		tp = 0
		num = 15
	else
		tp = bit.rshift(bit.band(card, 0xF0), 4)
		num = bit.band(card, 0x0F)
	end
	return num, tp
end 

local config_calc_time = 20
function TimerCalc(labelNode, bShow, curTime, timeoutFunc,everySecfunc)
	local curTime = curTime or config_calc_time
	labelNode:setVisible(bShow)
	labelNode:stopAllActions()
	if bShow then
		labelNode.lTimeCalc:SetString(str(curTime))
		labelNode.lTimeCalc:SetString(str(curTime))
		labelNode:DelayCall(1, function()
			curTime = curTime - 1
			if everySecfunc then
				everySecfunc(curTime)
			end
			if curTime < 0 then
				return
			end
			labelNode.lTimeCalc:SetString(str(curTime))
			if curTime == 0 and timeoutFunc then
				timeoutFunc()
			end
			return 1
		end)
	end
end
--新版倒计时，倒计时显示零秒，切多0.5秒
function TimerCalcNew(labelNode, bShow, curTime, timeoutFunc,everySecfunc)
	local curTime = (curTime or config_calc_time) - 1
	labelNode:setVisible(bShow)
	labelNode:stopAllActions()
	if bShow then
		labelNode.lTimeCalc:SetString(str(curTime))
		labelNode.lTimeCalc:SetString(str(curTime))
		labelNode:DelayCall(1, function()
			curTime = curTime - 1
			if everySecfunc then
				everySecfunc(curTime)
			end
			if curTime < 0 and timeoutFunc then
				timeoutFunc()
				return
			end
			labelNode.lTimeCalc:SetString(str(math.max(curTime,0)))
			if curTime == 0 then
				return 1.5
			end
			return 1
		end)
	end
end

-- 更新显示的卡牌 cardList 为已经排好序的牌
function UpdateMyCardInfo(self, bAni, sortedcardList, showCardsFun, isShowCard)
	local nCardLen = #sortedcardList

	-- 牌的选中状态
	local selStatus = {}

	for i = 1, nCardLen do table.insert(selStatus, false) end

	if bAni then
		self:get_layer():DelayCall(0.05, function()
			g_logicEventHandler:Trigger('logic_audio_play_event', 'AUDIO_PLAY_SOUND', 'PUSH_CARD')
		end)

		local showCardNumber = 0
		local cardTable = {}
		self:get_layer():DelayCall(0.05, function()
			showCardNumber = showCardNumber + 1
			table.insert(cardTable, sortedcardList[showCardNumber])
			showCardsFun(self.listMyCards, cardTable, isShowCard)
			if showCardNumber < nCardLen then
				return 0.05
			else
				-- 选牌逻辑
				self.layerSelect:SetContentSize('100%', 'i-20')
			end
		end)
	else
		showCardsFun(self.listMyCards, sortedcardList, isShowCard)
		-- 选牌逻辑
		self.layerSelect:SetContentSize('100%', 'i-20')
	end


	local startPos
	local endPos
	local i1, i2  -- 按下到松开的对应2个牌的索引

	local function _posForTouch(posx)
		if posx < 0 then
			posx = 0
		end

		return math.min(math.floor(posx / _width_card) + 1, nCardLen)
	end

	local function _updateSelCardsColor()
		if startPos == nil or endPos == nil then
			return
		end
		i1, i2 = _posForTouch(startPos.x), _posForTouch(endPos.x)
		if i1 > i2 then
			i1, i2 = i2, i1
		end
		for i = 1, nCardLen do
			local item = self.listMyCards:GetItem(i)
			if item then
				if i >= i1 and i <= i2 then
					item.spt:setColor(ccc3FromHex(0x999999))
				else
					item .spt:setColor(ccc3FromHex(0xffffff))
				end
			end
		end
	end

	-- 从我的牌中比较基础类型 如果查找到替换
	local function findAndReplace(cards, card)
		for i, v in ipairs(cards) do
			if bit.band(v, 0x0f) == bit.band(card, 0x0f) then
				cards[i] = card
				return cards
			end
		end
		return
	end

	-- 自动选择连
	local function autoSelectLine()
		if not self.lineRecommend or #self.lineRecommend == 0 then
			return
		end
		local selectIndex = {}
		for i, v in ipairs(selStatus) do
			if v then 
				selectIndex[#selectIndex + 1] = i
			end
		end
		if #selectIndex ~= 2 then return end
		if sortedcardList[selectIndex[1]] and sortedcardList[selectIndex[2]] and bit.band(sortedcardList[selectIndex[1]], 0x0f) == bit.band(sortedcardList[selectIndex[2]], 0x0f) then
			return
		end
		local autoSelectCards = {} -- 记录自动选择的cards
		for _, v in ipairs(self.lineRecommend) do
			if table.find_v(v, sortedcardList[selectIndex[1]]) and table.find_v(v, sortedcardList[selectIndex[2]]) then
				autoSelectCards = v
				break
			end
			if findAndReplace(v, sortedcardList[selectIndex[1]]) and findAndReplace(v, sortedcardList[selectIndex[2]]) then
				autoSelectCards = v
				break
			end

		end
		for i, v in ipairs(sortedcardList) do
			for index, value in ipairs(autoSelectCards) do
				if value == v then
					selStatus[i] = true
				end
			end
		end
	end

	self.layerSelect.OnBegin = function(pos)
		local allItems = self.listMyCards:GetAllItem()
		for i, v in ipairs(allItems) do
			local _, pointY = v:GetPosition()
			selStatus[i] = pointY == 20
		end
		startPos = self.listMyCards:convertToNodeSpace(pos)
		endPos = startPos
		_updateSelCardsColor()
		return true
	end

	self.layerSelect.OnDrag = function(pos)
		endPos = self.listMyCards:convertToNodeSpace(pos)
		_updateSelCardsColor()
	end

	self.layerSelect.OnEnd = function()
		local beforeSelectCount = table.count_if(selStatus, function(_, value)
			return value == true
		end)
		if i1 == nil or i2 == nil then
			return
		end
		for i = i1, i2 do
			selStatus[i] = not selStatus[i]
		end
		local afterSelectCount = table.count_if(selStatus, function(_, value)
			return value == true
		end)
		-- 根据我牌的选中状态更新我的牌的显示 并生成选中牌的数据

		if beforeSelectCount == 0 then
			local selectCards = {}
			for i = 1, #sortedcardList do
				if selStatus[i] then
					table.insert(selectCards, sortedcardList[i])
				end
			end
			ZhayouxiAutoSelectCards(self, selectCards, selStatus)
		end
		self._curSelCards = {}
		for i = 1, #sortedcardList do
			local item = self.listMyCards:GetItem(i)
			if item then
				item.spt:setColor(ccc3FromHex(0xffffff))
				local posx = item:getPosition()
				if selStatus[i] then
					table.insert(self._curSelCards, sortedcardList[i])
					item:setPosition(ccp(posx, 20))
				else
					item:setPosition(ccp(posx, 0))
				end
			end
		end
	end
end

function DoudiZhuListSendCard(cards, listSendCards, isLandLord)
	table.sort(cards, CardSort)
	listSendCards:SetInitCount(#cards)
	for i, v in ipairs(cards) do
		local item = listSendCards:GetItem(i)
		item.spt:SetPath('', GetCardPath(v))
		if i == #cards then
			item.sptLord:setVisible(isLandLord)
		end
	end
end
---------------------------------------------------------

function CardSort(v1, v2)
	local num1, num2 = bit.band(v1, 0x0F), bit.band(v2, 0x0F)
	if num1 <= 2 then
		num1 = num1 + 13
	elseif num1 >= 14 then
		num1 = num1 + 2
	end

	if num2 <= 2 then
		num2 = num2 + 13
	elseif num2 >= 14 then
		num2 = num2 + 2
	end

	if num1 ~= num2 then
		return num1 > num2
	else
		local tp1, tp2 = bit.rshift(bit.band(v1, 0xF0), 4), bit.rshift(bit.band(v2, 0xF0), 4)
		return	tp1 > tp2
	end
end

function UpdateMyCard(self, isNeedAnimate, card_list, landlord_uid, isShow, isAutoSelect, logic)
	self._curSortedListCards = card_list or {}
	table.sort(self._curSortedListCards, CardSort)

	local nCardLen = #self._curSortedListCards

	-- 清空我选择的牌
	self._curSelCards = {}
	-- 牌的选中状态
	self._selStatus = {}
	for i = 1, nCardLen do
		local item = self.listMyCards:GetItem(i)
		if item then
			item.spt:setColor(ccc3FromHex(0xffffff))
		end
	end

	-- 显示数据
	local showCardNumber = 0
	local cardTable = {}
	local function showMyCardAnimation(func)
		if #cardTable <= nCardLen then
			self:get_layer():DelayCall(0, function()
				-- self:HidenReadyTips()
				self.listMyCards:setVisible(true)
				func()
			end)
			-- 全部准备完成之后 展示牌的面板设置可见
			self:get_layer():DelayCall(0.05, function()
				if showCardNumber <= #card_list then
					showMyCardAnimation(func)
				else
					self._selStatus = {}
					self.layerSelect:SetContentSize('100%', 'i-20')
				end
			end)
		end
	end
	if isNeedAnimate then
		self:get_layer():DelayCall(1, function()
			g_logicEventHandler:Trigger('logic_audio_play_event','AUDIO_PLAY_SOUND', 'PUSH_CARD')
		end)
		showMyCardAnimation(function()
			showCardNumber = #cardTable + 1
			cardTable = {}
			for i=1, showCardNumber  do
				table.insert(cardTable, self._curSortedListCards[i])
			end
			self.listMyCards:SetInitCount(#cardTable)
			if self.showBoomAni then
				self:showBoomAni(cardTable)
			end
			for t, v in ipairs(cardTable) do
				local item = self.listMyCards:GetItem(t)
				item.spt:SetPath('', GetCardPath(v))
				local _userInfo = g_user_info
				if t == #cardTable then
					item.sptLord:setVisible(_userInfo.get_user_info().uid == landlord_uid)
				end
				item.sptShowCard:setVisible(isShow and #cardTable == t)
			end
		end)
	else
		self.listMyCards:SetInitCount(nCardLen)
		for i, v in ipairs(self._curSortedListCards) do
			local item = self.listMyCards:GetItem(i)
			item.spt:SetPath('', GetCardPath(v))
			local _userInfo = g_user_info
			if i == #self._curSortedListCards then
				item.sptLord:setVisible(_userInfo.get_user_info().uid == landlord_uid)
			end
			item.sptShowCard:setVisible(isShow and i == #self._curSortedListCards)
		end
	end
	self.layerSelect:SetContentSize('100%', 'i-20')

	local allItems = self.listMyCards:GetAllItem()
	for i, v in ipairs(allItems) do
		local _, pointY = v:GetPosition()
		table.insert(self._selStatus, pointY == 20)
		if pointY == 20 then
			self._curSelCards[#self._curSelCards + 1] = card_list[i]
		end
	end

	-- 选牌逻辑
	local startPos
	local endPos
	local i1, i2  -- 按下到松开的对应2个牌的索引

	local function _posForTouch(posx)
		if posx < 0 then
			posx = 0
		end

		return math.min(math.floor(posx / _width_card) + 1, nCardLen)
	end

	local function _updateSelCardsColor()
		if endPos == nil then return end
		if startPos == nil then return end
		i1, i2 = _posForTouch(startPos.x), _posForTouch(endPos.x)
		if i1 > i2 then
			i1, i2 = i2, i1
		end
		for i = 1, nCardLen do
			local item = self.listMyCards:GetItem(i)
			if item then
				if i >= i1 and i <= i2 then
					item.spt:setColor(ccc3FromHex(0x999999))
				else
					item.spt:setColor(ccc3FromHex(0xffffff))
				end
			end
		end
	end
	self.layerSelect.OnBegin = function(pos)
		startPos = self.listMyCards:convertToNodeSpace(pos)
		endPos = startPos
		_updateSelCardsColor()

		return true
	end

	self.layerSelect.OnDrag = function(pos)
		endPos = self.listMyCards:convertToNodeSpace(pos)
		_updateSelCardsColor()
	end

	self.layerSelect.OnEnd = function()
		local isHadSelect = false
		for i,status in pairs(self._selStatus) do
			if status then
				isHadSelect = true
			end
		end

		if i1 == nil or i2 == nil then return end
		for i = i1, i2 do
			self._selStatus[i] = not self._selStatus[i]
		end

		if not isHadSelect and isAutoSelect then
			--选出选中的卡
			local selectCards = {}
			for i = 1, #card_list do
				if self._selStatus[i] then
					table.insert(selectCards, card_list[i])
				end
			end
			AutoSelectCards(self, selectCards, logic)
		end
		UpdateSelectMyCard(self, card_list)
	end
end


function GetBoomNum(cards)
	local recommend_utils = import('dialog.doudizhu.doudizhu_room.doudizhu_recommend_utils')
	local playCardUtils = import('logic_net.play_card_recommend_utils')

	local myStaticCard = playCardUtils.cardStatic(cards, recommend_utils.powCard)
	local rocketTypeRcmds = recommend_utils.rocketBigger(myStaticCard.SINGLE)
	return #myStaticCard.FOUR + #rocketTypeRcmds
end

function AutoSelectCards(self, selectCards, logic)
	local recommend_utils = import('dialog.doudizhu.doudizhu_room.doudizhu_recommend_utils')
	local playCardUtils = import('logic_net.play_card_recommend_utils')

	if logic == nil then
		if g_game_mgr.is_in_game('GameType_DOUDIZHU') then
			logic = g_game_mgr.get_game('GameType_DOUDIZHU'):GetDdzCoinsLogic()
		elseif g_game_mgr.is_in_game('GameType_TAODOU') then
			logic = g_game_mgr.get_game('GameType_TAODOU'):GetGameLogic()
		end
	end

	if logic == nil or logic.game_room_info == nil then
        return
    end

    local cardstype, smallCard = recommend_utils.getCardType(selectCards)
    if cardstype ~= recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_UNKNOWN and cardstype ~= recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_SINGLE then
    	--已经是特殊牌型的情况
    	return 
    end
    if not logic.game_my_cards then return end

    local myCards = table.deepcopy(logic.game_my_cards)
    local card_list = nil
    local card_info = nil

    if g_game_mgr.is_in_game('GameType_DDZ_ROOM') then
    	local play_logs = logic.game_room_info.play_logs.play_logs or {}
	    for i, v in ipairs(play_logs) do
	        if v.card_list and #v.card_list ~= 0 then
	            card_list = v.card_list
	            card_info = v
	        end
	    end
		if card_info and card_info.uid == g_user_info.get_user_info().uid then
	    	card_list = nil
	    end
    else
	    local play_logs = logic.game_room_info.play_logs
	    for i, v in ipairs(play_logs) do
	        if v.cards and #v.cards ~= 0 then
	            card_list = v.cards
	            card_info = v
	        end
	    end
		if card_info and card_info.player_id == g_user_info.get_user_info().uid then
	    	card_list = nil
	    end
	end

    local selectRecommendCards = function(selectCards)
    	local baseCardList = recommend_utils.MapingCard(selectCards)
		local recommendCards = playCardUtils.translateByMyCard(myCards, baseCardList)
		if recommendCards ~= nil then
			for i, v in ipairs(myCards) do
				self._selStatus[i] = table.find_v(recommendCards[1], v) ~= nil
			end
		end
	end

    if card_list ~= nil and  #card_list == 2 and #selectCards == 1 then
    	--对手出对牌，我选中单牌
    	local num, tp = GetCardType(selectCards[1])
    	for i,v in ipairs(myCards) do
    		if selectCards[1] ~= v and num == GetCardType(v) then
    			self._selStatus[i] = true
    			return
    		end
    	end
    end

    local recommendCards
    local myStaticCard = playCardUtils.cardStatic(selectCards, recommend_utils.powCard)
	local cardsSingle = playCardUtils.contact(myStaticCard.SINGLE, myStaticCard.DOUBLE, myStaticCard.THREE, myStaticCard.FOUR)
	local cardsDouble = playCardUtils.contact(myStaticCard.DOUBLE, myStaticCard.THREE, myStaticCard.FOUR)
	local cardsThree = playCardUtils.contact(myStaticCard.THREE, myStaticCard.FOUR)


    if card_list ~= nil and #card_list > 0 then
    	local cardstype, smallCard = recommend_utils.getCardType(card_list)
    	--顺子的时候
    	if cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_LINE  then
    		recommendCards = playCardUtils.lineBigger(cardsSingle, smallCard, #card_list)
    		if recommendCards ~= nil and #recommendCards > 0 then
				return selectRecommendCards(recommendCards)
			end 
    	end
    	--连对的时候
    	if cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_2LINE  then
    		recommendCards = playCardUtils.duplicateRcmds(2, playCardUtils.lineBigger(cardsDouble, smallCard, #card_list/2))
    		if recommendCards ~= nil and #recommendCards > 0 then
				return selectRecommendCards(recommendCards)
			end 
    	end
    	--飞机的时候
    	if cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_3LINE or 
		cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_3LINE_TAKE_1 or
		cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_3LINE_TAKE_2 then
			local length = #card_list/3
			if cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_3LINE_TAKE_1 then
				length = #card_list/4
			elseif cardstype == recommend_utils.PLAY_CARD_TYPE.CARD_TYPE_3LINE_TAKE_1 then
				length = #card_list/5
			end 

    		recommendCards = playCardUtils.duplicateRcmds(3, playCardUtils.lineBigger(cardsThree, tp, length))
    		if recommendCards ~= nil and #recommendCards > 0 then
				return selectRecommendCards(recommendCards)
			end 
    	end
    end

	--寻找顺子
	for i = 13,5,-1 do
		recommendCards = playCardUtils.lineBigger(cardsSingle, 1, i)
		if recommendCards ~= nil and #recommendCards > 0 then
			--有相同长度的飞机
			if i <= 5 then
				local threeCards = playCardUtils.duplicateRcmds(3, playCardUtils.lineBigger(cardsThree, 1, i))
				if threeCards ~= nil and #threeCards > 0 then
					return selectRecommendCards(threeCards)
				end
			end
			--有相同长度的连对
			if i <= 8 then
				local doubleCards = playCardUtils.duplicateRcmds(2, playCardUtils.lineBigger(cardsDouble, 1, i))
				if doubleCards ~= nil and #doubleCards > 0 then
					return selectRecommendCards(doubleCards)
				end
			end
			return selectRecommendCards(recommendCards)
		end
	end
	--寻找连对
	for i = 8,3,-1 do
		recommendCards = playCardUtils.duplicateRcmds(2, playCardUtils.lineBigger(cardsDouble, 1, i))
		--有相同长度的飞机
		if i <= 5 then
			local threeCards = playCardUtils.duplicateRcmds(3, playCardUtils.lineBigger(cardsThree, 1, i))
			if threeCards ~= nil and #threeCards > 0 then
				return selectRecommendCards(threeCards)
			end
		end

		if recommendCards ~= nil and #recommendCards > 0 then
			return selectRecommendCards(recommendCards)
		end
	end

	for i = 5,2,-1 do
		recommendCards = playCardUtils.duplicateRcmds(3, playCardUtils.lineBigger(cardsThree, 1, i))
		if recommendCards ~= nil and #recommendCards > 0 then
			return selectRecommendCards(recommendCards)
		end
	end
end


local function _zhayouxiCardSort(v1, v2)
	local num1, num2 = bit.band(v1, 0x0F), bit.band(v2, 0x0F)
	if num1 <= 3 then
		num1 = num1 + 13
	elseif num1 >= 14 then
		num1 = num1 + 3
	end

	if num2 <= 3 then
		num2 = num2 + 13
	elseif num2 >= 14 then
		num2 = num2 + 3
	end

	if num1 ~= num2 then
		return num1 > num2
	else
		local tp1, tp2 = bit.rshift(bit.band(v1, 0xF0), 4), bit.rshift(bit.band(v2, 0xF0), 4)
		return	tp1 > tp2
	end
end

-- 显示指定的牌
function ZhayouxiShowCards(listCtrl, listCards, isShowCard)
	table.sort(listCards, _zhayouxiCardSort)
	listCtrl:SetInitCount(#listCards)
	for i, v in ipairs(listCards) do
		local item = listCtrl:GetItem(i)
		item.spt:SetPath('', GetCardPath(v))
		item.sptShowCard:setVisible(isShowCard and #listCards == i)
	end
end

local function _zhayouxiUpdateMyCardInfo(self, bAni, cardList, isShowCard)
	if cardList then
		table.sort(cardList, _zhayouxiCardSort)
		UpdateMyCardInfo(self, bAni, cardList, ZhayouxiShowCards, isShowCard)
	end
end

function ZhayouxiSetupPlayCardLogic(self)
	self._curSelCards = {}  -- 打牌的时候选中的牌
	self.listMyCards = self.player1.listMyCards
	self.layerSelect = self.player1.layerSelect
	self.UpdateMyCardInfo = _zhayouxiUpdateMyCardInfo
end


-- 根据我牌的选中状态更新我的牌的显示 并生成选中牌的数据
function UpdateSelectMyCard(self, myCards)
	-- 更新选中的状态
	self._curSelCards = {}
	for i = 1, #myCards do
		local item = self.listMyCards:GetItem(i)
		if not item then return end
		item.spt:setColor(ccc3FromHex(0xffffff))

		local posx = item:getPosition()
		if self._selStatus[i] then
			table.insert(self._curSelCards, myCards[i])
			item:setPosition(ccp(posx, 20))
		else
			item:setPosition(ccp(posx, 0))
		end
	end
end

-- 显示下一个推荐的牌
function ShowNextRecommendCards(self, myCards)
	local cards = nil

	if self._recommendCards == nil or #self._recommendCards == 0 then
		return
	else
		if self._nCurRecommendIndex == nil or self._nCurRecommendIndex == #self._recommendCards then
			self._nCurRecommendIndex = 1
		else
			self._nCurRecommendIndex = self._nCurRecommendIndex + 1
		end
		cards = self._recommendCards[self._nCurRecommendIndex]
	end

	self._selStatus = {}
	myCards = myCards or {}
	for i, v in ipairs(myCards) do
		self._selStatus[i] = cards ~= nil and table.find_v(cards, v) ~= nil
	end

	UpdateSelectMyCard(self, myCards)
end

-- 炸游戏排序
function ZhayouxiSortCards(cards)
	table.sort(cards, _zhayouxiCardSort)
	return cards
end

-- 验证用户的牌 如果非法 上传
function VertifyUserCard(iden, cards)
	local card_map = {}
	for _, v in ipairs(cards) do
		local num, tp = GetCardType(v)
		if card_map[num] == nil then
			card_map[num] = {}
		end
		if #card_map[num] >= 4 then	-- 对应单张牌的个数大于4张 非法牌 上传
			utils_test_upload_log2server('release_ddz_cards_error/color', {identify = iden,card=cards, uid = g_user_info.get_user_info().uid, time = str(GetServerTimeStamp())})
			return
		end
		if table.find_v(card_map[num], tp) then	-- 存在重复花色 非法牌 上传
			utils_test_upload_log2server('release_ddz_cards_error/repeat', {identify = iden, card=cards, uid = g_user_info.get_user_info().uid, time = str(GetServerTimeStamp())})
			return
		end
		card_map[num][#card_map[num] + 1] = tp
	end
end

-- 春天特效
function ShowSpring(data)
    if data.god_card == 1 then
        g_panel_mgr.show('common.dlg_common_animation', 'poker_type_ani_spring')
    end
end

-- 春天特效
function ShowSpringNew(data,musicId)
    -- g_logicEventHandler:Trigger('logic_audio_play_event', 'AUDIO_PLAY_SOUND', musicId)
    g_panel_mgr.show('common.dlg_common_animation', 'poker_type_ani_spring_new')
end

local current_ani_name = ""
function GetCurrentCommonAnimationTemplateName()
	if current_ani_name == "poker_type_ani_spring" or current_ani_name == 'poker_type_ani_spring_new' then
		return "common/animation/animation_chuntian"
	elseif current_ani_name == 'poker_tyep_ani_rocket' or current_ani_name == 'poker_tyep_ani_feiji' or current_ani_name == 'poker_tyep_ani_feiji_new' then
		return "common/animation/animation_feiji"
	elseif current_ani_name == 'poker_type_ani_zhadan' then
		return "common/animation/animation_zhadan"
	elseif current_ani_name == 'poker_type_ani_2line' then
		return "common/animation/animation_liandui"
	elseif current_ani_name == 'poker_type_abu_line' then
		return "common/animation/animation_shunzi"
	end
	return ""
end

function ShowCommonAnimationPanel(aniName, func,framDelay)
	if logic_utils_can_use_spine() then
		current_ani_name = aniName
		local check_template_name = GetCurrentCommonAnimationTemplateName()
		if check_template_name == '' then
			__G__TRACKBACK__(string.format("invalid ani name %s ", aniName))
		else
			g_panel_mgr.show('common.dlg_common_animation_spine', aniName, func, frameDelay)
		end
		
		current_ani_name = ''
	else
		g_panel_mgr.show('common.dlg_common_animation', aniName, func, frameDelay)
	end
end

-- 播放动画
function PlayCardAnimation(data)
    local animationCardType = {
        CARD_TYPE_LINE = 8, --顺子 8
        CARD_TYPE_2LINE = 9, --顺子 9
        CARD_TYPE_3LINE = 10, --飞机 10
        CARD_TYPE_3LINE_TAKE_1 = 11, --飞机 11
        CARD_TYPE_3LINE_TAKE_2 = 12, --飞机 12
        CARD_TYPE_BOMB = 13, --炸弹 13
        CARD_TYPE_ROCKET = 14, --王炸 14
    }
    local animationMap = {
        [animationCardType.CARD_TYPE_LINE] = 'poker_type_abu_line', 
        [animationCardType.CARD_TYPE_2LINE] = 'poker_type_ani_2line', 
        [animationCardType.CARD_TYPE_3LINE] = 'poker_tyep_ani_feiji', 
        [animationCardType.CARD_TYPE_3LINE_TAKE_1] = 'poker_tyep_ani_feiji', 
        [animationCardType.CARD_TYPE_3LINE_TAKE_2] = 'poker_tyep_ani_feiji', 
        [animationCardType.CARD_TYPE_BOMB] = 'poker_type_ani_zhadan', 
        [animationCardType.CARD_TYPE_ROCKET] = 'poker_tyep_ani_rocket', 
    }
    local aniName = animationMap[data.card_type]
    if aniName then
        g_panel_mgr.show('common.dlg_common_animation', aniName, function()
        end)
    end
end

local animationCardType = {
    CARD_TYPE_LINE = 8, --顺子 8
    CARD_TYPE_2LINE = 9, --连对 9
    CARD_TYPE_3LINE = 10, --飞机 10
    CARD_TYPE_3LINE_TAKE_1 = 11, --飞机 11
    CARD_TYPE_3LINE_TAKE_2 = 12, --飞机 12
    CARD_TYPE_BOMB = 13, --炸弹 13
    CARD_TYPE_ROCKET = 14, --王炸 14
}
local musicMap = {
    	[animationCardType.CARD_TYPE_3LINE] = 55, 
        [animationCardType.CARD_TYPE_3LINE_TAKE_1] = 56, 
        [animationCardType.CARD_TYPE_3LINE_TAKE_2] = 57, 
}

local animationMap = {
        [animationCardType.CARD_TYPE_LINE] = 'poker_type_abu_line', 
        [animationCardType.CARD_TYPE_2LINE] = 'poker_type_ani_2line', 
        [animationCardType.CARD_TYPE_3LINE] = 'poker_tyep_ani_feiji_new', 
        [animationCardType.CARD_TYPE_3LINE_TAKE_1] = 'poker_tyep_ani_feiji_new', 
        [animationCardType.CARD_TYPE_3LINE_TAKE_2] = 'poker_tyep_ani_feiji_new', 
        [animationCardType.CARD_TYPE_BOMB] = 'poker_type_ani_zhadan', 
        [animationCardType.CARD_TYPE_ROCKET] = 'poker_tyep_ani_rocket', 
}
local frameDelayMap = {
    -- [animationCardType.CARD_TYPE_BOMB] = 0.033, 
    -- [animationCardType.CARD_TYPE_ROCKET] = 0.033, 
}

function PlayCardAnimationMusic(data)
	local musicId = musicMap[data.card_type]
    if musicId ~= nil then
        g_logicEventHandler:Trigger('logic_audio_play_event', 'AUDIO_PLAY_SOUND', musicId)
    end
end

local pathMap = {
	-- --炸弹
	-- 'gui/Animation/doudizhu/zhadan/zijirengzhadan/zijireng.png',
	-- 'gui/Animation/doudizhu/zhadan/bierenrengzhadan/bierenreng.png',
	-- 'gui/Animation/doudizhu/zhadan/baozha1/baozha.png',
	-- 'gui/Animation/doudizhu/zhadan/baozha2/baozha.png',
	-- 'gui/Animation/doudizhu/zhadan/wenzi/wenzi.png',
	-- --火箭
	-- 'gui/ani_template/template_animations/wangzhaliiz/baozhaguangban.png',
	-- 'gui/ani_template/template_animations/wangzhaliiz/baozhaguangdian.png',
	-- 'gui/ani_template/template_animations/wangzhaliiz/moguyun1.png',
	-- 'gui/ani_template/template_animations/wangzhaliiz/moguyun2.png',
	-- 'gui/ani_template/template_animations/wangzhaliiz/shangshengyanwu.png',
	-- 'gui/ani_template/template_animations/wangzhaliiz/shikuai.png',
	-- 'gui/ani_template/template_animations/wangzhaliiz/xialuojuji.png',
	-- 'gui/ani_template/template_animations/wangzhayanwu/wangzhayanwu/wangzhayanwu.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/cloud.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/floor.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/huojian.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/huoyan_00005.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light1.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light2.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light3.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light4.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light5.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light6.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/light7.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/rock.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/txt_wangzha.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/yun.png',
	-- 'gui/Animation/doudizhu/ani_wangzha/yunyun.png',
	-- --春天
	'gui/Animation/doudizhu/chuntian/chuntianhau1/chuntianhua.png',
	'gui/Animation/doudizhu/chuntian/chuntianhua2/chuntianhua.png',
	'gui/Animation/doudizhu/chuntian/chuntianwenzi.png',

	-- --顺子
	-- 'gui/Animation/doudizhu/shunzi/guangixao/shunzi.png',
	-- 'gui/Animation/doudizhu/shunzi/wenzi/shunziwenzi.png',
	-- --连对
	-- 'gui/Animation/doudizhu/liandui/liandui1/liandui.png',
	-- 'gui/Animation/doudizhu/liandui/liandui2/liandui.png',
	-- 'gui/Animation/doudizhu/liandui/liandui3/liandui.png',
	-- 'gui/Animation/doudizhu/liandui/wenzi/wenzi.png',
	--飞机
	'gui/Animation/doudizhu/feiji/wenzi/txt_feiji.png',
	'gui/Animation/doudizhu/feiji/feiji.png',
}
--加载游戏炸弹资源
function load_ani_images(data,panel)
	utils_enable_schedule_collect_garbage(false)
	utils_add_images_async(pathMap,function()
	end)
end

local addParticel = function(path, parent, delay)
	parent:DelayCall(delay,function()
		local particel = cc.ParticleSystemQuad:create(path)
		parent:addChild(particel)
		particel:SetPosition('50%','50%')
	end)
end

-- 播放新版动画
function PlayNewCardAnimation(data,panel)
	-- data.card_type = animationCardType.CARD_TYPE_3LINE_TAKE_1
	PlayCardAnimationMusic(data)
	local aniName = animationMap[data.card_type]
	-- if type(aniName) == 'table' then
	-- 	aniName = aniName[panel:GetItemIndexById(data.player_id)]
	-- end

	local frameDelay = frameDelayMap[data.card_type] or 0.1
	if aniName then
	    g_panel_mgr.show('common.dlg_common_animation', aniName, function()
	    end,frameDelay)
	end
		-- if data.card_type == animationCardType.CARD_TYPE_LINE or data.card_type == animationCardType.CARD_TYPE_2LINE then
		-- 	local aniNode = panel['player'..panel:GetItemIndexById(data.player_id)].cardAnimationNode.aniNode
		-- 	aniNode:stopAllActions()
		-- 	if data.card_type == animationCardType.CARD_TYPE_LINE then
		-- 		aniNode:PlayAnimation('poker_type_abu_line_new')
		-- 	else
		-- 		aniNode:PlayAnimation('poker_type_ani_2line_new')
		-- 	end
		-- end

	if data.card_type == animationCardType.CARD_TYPE_ROCKET then
		-- local ani = g_uisystem.play_template_animation('doudizhucoins/effect/ani_wangzha', 'ani_wangzha', panel:get_layer())
		-- addParticel('gui/Animation/doudizhu/wangzha/wangzhaliiz/xialuojuji.plist',ani,1.4)
		-- addParticel('gui/Animation/doudizhu/wangzha/wangzhaliiz/shangshnegyanwu.plist',ani,1.6)
		-- addParticel('gui/Animation/doudizhu/wangzha/wangzhaliiz/baozhaguangban.plist',ani,1.7)
		-- addParticel('gui/Animation/doudizhu/wangzha/wangzhaliiz/shikuai.plist',ani,1.7)
		-- addParticel('gui/Animation/doudizhu/wangzha/wangzhaliiz/baozhaguangdian.plist',ani,1.8)

		panel:get_layer():DelayCall(0.5, function()
        	common_shake_action(panel:get_layer(),20)
    	end)
    	
    	-- panel:get_layer():DelayCall(3, function()
     --    	ani:removeFromParent()
    	-- end)
	end

end

function IsRob(logic)
    for i = #logic.call_logs, 1, -1 do
        local log = logic.call_logs[i]
        if log.player_id == 0 then
            return false
        end
        if log.action == 2 or log.action == 3 then
            return true
        end
    end
    return false
end

-- 播放音效
function PlayCardSound(logic)
    if not logic.game_room_info or #logic.game_room_info.play_logs == 0 then
        return
    end
    local player_list = logic.game_room_info.player_list
    local play_log = logic.game_room_info.play_logs[#logic.game_room_info.play_logs]
    for _, v in ipairs(player_list) do
        if v.player_id == play_log.player_id then
            play_log.card_list = play_log.cards
            if play_log.card_type == 0 then 
                play_log.is_passed = true
            end
            g_logicEventHandler:Trigger('logic_audio_play_event', 'AUDIO_PLAY_CARD', play_log, v.gender)
        	return
        end
    end
end

-- 播放聊天的声音
function PlayChatAudio(logic,data)
    if not logic.game_room_info or not logic.game_room_info.player_list then
        return
    end
    local gender = 0
    for _, v in ipairs(logic.game_room_info.player_list) do
        if data.player_id == v.player_id then
            gender = v.gender
        end
    end
    local contentIndex = tonumber(data.msg)
    if not contentIndex then return end
    g_logicEventHandler:Trigger('logic_audio_play_event', 'AUDIO_CHAT_SOUND', contentIndex + 1, gender)
end

function ZhayouxiAutoSelectCards(self, selectCards, selStatus)
	local recommend_utils = import('dialog.zhayouxi.zhayouxi_recommend_utils')
	local playCardUtils = import('logic_net.play_card_recommend_utils')

	local logic = g_game_mgr.get_game('GameType_ZYX'):GetGameLogic()
	if not logic.game_room_info then
        return
    end
	
    local cardstype, smallCard = recommend_utils.getCardType(selectCards)
    local play_logs = logic.game_room_info.play_logs
    local myCards = table.deepcopy(logic.game_my_cards)

	if not logic.game_my_cards then 
		return 
	end

    local card_list = nil
    local card_info = nil
    for i, v in ipairs(play_logs) do
        if v.cards and #v.cards ~= 0 then
            card_list = v.cards
            card_info = v
        end
    end

    if card_info and card_info.player_id == g_user_info.get_user_info().uid then
    	card_list = nil
    end

    local selectRecommendCards = function(selectCards)
    	local baseCardList = recommend_utils.MapingCard(selectCards)
		local recommendCards = playCardUtils.translateByMyCard(myCards, baseCardList)
		if recommendCards ~= nil then
			for i, v in ipairs(myCards) do
				selStatus[i] = table.find_v(recommendCards[1], v) ~= nil
			end
		end
	end

    if card_list ~= nil and  #card_list == 2 and #selectCards == 1 then
    	--对手出对牌，我选中单牌
    	local num, tp = GetCardType(selectCards[1])
    	for i,v in ipairs(myCards) do
    		if selectCards[1] ~= v and num == GetCardType(v) then
    			selStatus[i] = true
    			return
    		end
    	end
    end

    local recommendCards
    local myStaticCard = playCardUtils.cardStatic(selectCards, recommend_utils.powCard)
	local cardsSingle = playCardUtils.contact(myStaticCard.SINGLE, myStaticCard.DOUBLE, myStaticCard.THREE, myStaticCard.FOUR)
	local cardsDouble = playCardUtils.contact(myStaticCard.DOUBLE, myStaticCard.THREE, myStaticCard.FOUR)

    
    if card_list ~= nil and #card_list > 0 then
    	local cardstype, smallCard = recommend_utils.getCardType(card_list)
    	--顺子的时候
    	if cardstype == recommend_utils.PLAY_CARD_TYPE.CT_LINE  then
    		recommendCards = playCardUtils.lineBigger(cardsSingle, smallCard, #card_list)
    		if recommendCards ~= nil and #recommendCards > 0 then
				return selectRecommendCards(recommendCards)
			end 
    	end
    	--连对的时候
    	if cardstype == recommend_utils.PLAY_CARD_TYPE.CT_DLINE  then
    		recommendCards = playCardUtils.duplicateRcmds(2, playCardUtils.lineBigger(cardsDouble, smallCard, #card_list/2))
    		if recommendCards ~= nil and #recommendCards > 0 then
				return selectRecommendCards(recommendCards)
			end 
    	end
    end
	
	--寻找顺子
	for i = 13, 4, -1 do
		recommendCards = playCardUtils.lineBigger(cardsSingle, 1, i)
		if recommendCards ~= nil and #recommendCards > 0 then
			--有相同长度的连对
			if i <= 8 then
				local doubleCards = playCardUtils.duplicateRcmds(2, playCardUtils.lineBigger(cardsDouble, 1, i))
				if doubleCards ~= nil and #doubleCards > 0 then
					return selectRecommendCards(doubleCards)
				end
			end

			return selectRecommendCards(recommendCards)
		end
	end

	--寻找连对
	for i = 8,3,-1 do
		recommendCards = playCardUtils.duplicateRcmds(2, playCardUtils.lineBigger(cardsDouble, 1, i))
		if recommendCards ~= nil and #recommendCards > 0 then
			return selectRecommendCards(recommendCards)
		end
	end
end

function CheckFinishCall(callLogs)
	local startIndex = 0
	for i = #callLogs, 1, -1 do
		if callLogs[i].action == 0 then
			startIndex = i - 1
			break
		end
	end
	if (#callLogs - startIndex) >= 5 then
		return true
	end
	if (#callLogs - startIndex) == 4 then
        if callLogs[startIndex + 2].action == 1 then --我不叫地主
        	return true
        elseif callLogs[startIndex + 3].action == 1 and callLogs[startIndex + 4].action == 1 then --没人抢地址
        	return true
        end
    end
    return false
end

local function get_posx_by_index(self, listMyCards, index, total_count)
	local screen_width, screen_height = self:get_layer():GetContentSize()
	local posX = listMyCards:GetPosition()
	local scale_x = listMyCards:getScale()
	local horBorder = listMyCards:GetHorzBorder()
	local horzIndent = listMyCards:GetHorzIndent()
	local itemSize = listMyCards:GetCtrlSize()
	local scaleX = listMyCards:getScaleX()
	local list_width = (itemSize.width + horBorder + (total_count - 1) * (itemSize.width + horzIndent)) * scaleX
	local item_pos = (index - 1) * (itemSize.width + horzIndent)
	return item_pos
end

local function move_landlord_cards(self, listMyCards)
	local allItems = listMyCards:GetAllItem()
    for i, item in ipairs(allItems) do
        if not item:isVisible() then
            item:setVisible(true)
            local posx, posy = item:GetPosition()
            item:SetPosition(posx, posy + 80)
        end
    end
end

-- 展示地主牌的动画
function show_landlord_card_animation(self, listMyCards, all_cards, landlords, landlord_uid)
	
	local all_cards_copy = table.deepcopy(all_cards)
	local landlords_copy = table.deepcopy(landlords)
	for _, v in ipairs(landlords_copy) do
		table.arr_remove_v(all_cards_copy, v)
	end
	local old_seventeen_cards = landlords_copy
	local sevent_teen_pos = {}
	local twenty_pos = {}
	local sevent_cards = 17
	local twenty_cards = 20
	for i = 1, sevent_cards do
		local posx = get_posx_by_index(self, listMyCards, i, sevent_cards)
		sevent_teen_pos[#sevent_teen_pos + 1] = posx
	end

	for i = 1, twenty_cards do
		local posx = get_posx_by_index(self, listMyCards, i, twenty_cards)
		twenty_pos[#twenty_pos + 1] = posx
	end

	self:UpdateMyCard(false, all_cards)
	local my_cards = table.deepcopy(all_cards)
    table.sort(my_cards, CardSort)
    local posIndex = 0
    local otherIndex = 0
    for index, value in ipairs(my_cards) do
        local item = listMyCards:GetItem(index)
        local key = table.find_v(landlords_copy, value)
        if key then
            otherIndex = otherIndex + 1
            item:setVisible(false)
        else
            posIndex = posIndex + 1
            local posx = sevent_teen_pos[posIndex] + (sevent_teen_pos[2] - sevent_teen_pos[1]) * 1.5
            item:SetPosition(posx, 0)
        end
    end

    local allItems = listMyCards:GetAllItem()
    local index = 0
    move_landlord_cards(self, listMyCards)
    for i, item in ipairs(allItems) do
        local _, posY = item:GetPosition()
        if posY == 0 then
            item:runAction(cc.MoveTo:create(0.5, ccp(twenty_pos[i], 0)))
        else
            local posx = twenty_pos[i]
            local delayCall = cc.DelayTime:create(0.3)
            local action2 = cc.MoveTo:create(0.2, ccp(posx, 0))
            local callback = cc.CallFunc:create(function()
            	self:UpdateMyCard(false, all_cards)
            end)
            local callback2 = cc.CallFunc:create(function()
                self:UpdateMyCard(false, all_cards)
            end)
            local sequeue = cc.Sequence:create(delayCall, action2, callback, delayCall, callback2)
            item:runAction(sequeue)
        end
    end
end